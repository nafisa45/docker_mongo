# farm-part-1
FARM Stack with Docker Compose - Part 1. A full description of the code can be found at https://medium.com/@chupati/farm-stack-with-docker-compose-part-1-mongodb-54cc65e31636.

Once you copy the repo you can type the following command assuming you have Docker Compose installed on your machine.

docker-compose up
